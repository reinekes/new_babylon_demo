# Sheep asset source

Model: Sheep (rigged, textured and animated)
Author: p0ss
Source: https://opengameart.org/content/sheep-rigged-textured-and-animated
Original download: https://opengameart.org/sites/default/files/sheepies.blend
License: Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
License URL: https://creativecommons.org/licenses/by-sa/3.0/

Texture source: boar-TT7020726 photograph by titus tscharntke, via p0ss Woodland Animals Texture Pack, https://opengameart.org/content/woodland-animals-texture-pack .

Original source retained as sheepies.blend. packed-image-1.png extracted byte-for-byte from embedded PNG data (1024x1024). Adaptation: selected medium-fleece Sheep 2, retained authored mesh/UV/weights and seven animations, repaired legacy bone-parent hierarchy for glTF skinning, rebuilt material with original packed diffuse texture, applied 0.49 scale and ground-centered orientation, renamed clips. Adapted model and editable source: sheep.glb / sheep-adapted.blend, licensed CC BY-SA 3.0. Reproducible conversion: prepare_sheep.py (bpy 4.5.3).

Redistributed adaptations must identify changes, credit p0ss and the texture source, link the license and be released under CC BY-SA 3.0 or a permitted compatible license.

The author preview is rendersheep6.png. The final wool-growth stage is deliberately exaggerated; use a leaner stage for naturally proportioned sheep. Historical breed accuracy has not been established.
