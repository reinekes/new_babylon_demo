# Resident asset provenance and license

The adapted `sumer-resident.glb` and `sumer-resident-lod.glb`, added clothing/hair/beard/eye geometry, retargeting adjustments and newly authored Idle_Loop may be used, modified and redistributed under CC0 1.0 Universal:
https://creativecommons.org/publicdomain/zero/1.0/

Original base: Innerscene / MakeHuman / MPFB CC0 body and rig, **Human base mesh with editable 53-bone rig**:
https://www.innerscene.com/tools/library/3d-parts/human-base-mesh-with-editable-53-bone-rig-8e7c8ab1
The adapting author's primary page explicitly releases the model CC0. Its description identifies MakeHuman/MPFB body, rig and skin assets as CC0. Source snapshot: innerscene-53.html.

Original walk: Innerscene, **Brisk walk - Sam 3D Person, Animated**:
https://www.innerscene.com/tools/library/3d-parts/brisk-walk-sam-3d-person-animated-bed03fa4
The author expressly describes original periodic authored pose recipes, no motion-capture data, MakeHuman/MPFB CC0 source, and CC0 release. Source snapshot: innerscene-sam.html.

Adaptation: reduced mesh density; original base's complete face/hands/feet preserved; weighted wool-like wrap skirt and fitted shoulder garment; warm matte tan material; body-surface-derived dark hair cap and close beard; small fitted dark eye patches; rest-corrected and reduced-amplitude walk baked onto the 53-bone target; per-frame sole grounding. Idle is a newly authored standing breathing/head-motion loop, not motion capture. Procedural surface weave appears in Blender; GLB preserves base materials rather than baking weave to image textures.

This is an artist's simplified Sumer-inspired prototype resident, not a historically authenticated reconstruction. Final garment styling, hair, regional anatomy, texture detail, cloth movement and performance require product acceptance. The brisk walk source is authored animation, not measured human motion. Do not imply source assets were made by this project.

No Mixamo / char-kit / unverified third-party mocap is included. Quaternius candidates were researched and downloaded separately but are not included in this final resident.

The crowd LOD additionally uses a voxel-remeshed continuous body with nearest-surface transfer of the same licensed source weights, lower-detail scalp/beard and clothing. Its original independently authored Idle_Loop and original-source-retargeted Walk_Loop remain CC0.

Final garment refinement: asymmetrical diagonal one-shoulder wrap, plus64short13mmweighted fringe teeth per hem, authored here and dedicated CC0. This remains a simplified art interpretation, not a verified reconstruction of one specific surviving garment.

Final crowd optimization joins the existing seven weighted meshes into one and bakes their same solid colors to vertex colors; no new external assets. Same CC0 dedication applies.
