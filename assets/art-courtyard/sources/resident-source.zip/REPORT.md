# Human asset selection — 2026-10-20

## Final adapted asset (implemented)

`/tmp/art-human-selection/sumer-resident.glb` — self-contained clothed natural human,1,548,432bytes,22,876triangles,53bone skin,7meshes. Walk_Loop1.733333s and Idle_Loop3s. The implementation and source `.blend` are in `prepare_human.py` and `sumer-resident.blend`; licenses/provenance in `RESIDENT_LICENSE.md`; numerical checks in `resident-stats.json` and `roundtrip-report.json` (when complete).

Adaptations completed: reduced body mesh; fitted wool-colored skirt with pleats, shoulder wrap; warm tan skin; anatomically fitted surface hair cap/beard and dark eyes; rest-corrected authored CC0 walk,80%rotation amplitude,small upper-arm outward correction for cloth clearance,per-frame sole grounding; newly authored standing breathing/head idle. No imported mocap, no nude unadapted model exported. Export has no external image dependencies and no hidden bone widgets. Procedural cloth weave stays in the Blender source; GLB has flat PBR materials.

Walk evaluated in Blender across53samples: minZ=.00199994m; union bounds[-.453795,-.663558,.002] to[.457930,.427053,1.745124]m. Idle91samples union bounds[-.321536,-.360917,.002515] to[.321298,.244320,1.688704]m;footpositionsconstant. Three gait frames rendered and inspected. Some wool borders remain roughly triangulated/frayed, the walk is brisk stylized authored motion, and no cloth simulation or runtime LOD is included. This is a licensed prototype asset suitable for user review, not a claim of Banished production quality or historical authentication.


## Selected natural body and verified CC0 walk

Best source pair obtained (parent suggested these candidates):
- `/tmp/art-human-selection/natural-base-53.glb`: https://www.innerscene.com/tools/library/3d-parts/human-base-mesh-with-editable-53-bone-rig-8e7c8ab1 ; 4,994,640 bytes,107,024triangles,one mesh/one gray material,53 joints,no animation. Actual author preview inspected at `natural-base-preview.png`: smooth anatomical body, complete face/hands/feet, neutral human proportions, no modern clothing, no hair. Good natural body foundation; needs skirt, skin/hair materials and mesh simplification.
- `/tmp/art-human-selection/sam-walk.glb`: https://www.innerscene.com/tools/library/3d-parts/brisk-walk-sam-3d-person-animated-bed03fa4 ; 21,013,304bytes,91,610triangles,56joints,Walk_Brisk clip. Author expressly states original periodic authored pose recipe, no motion capture, MakeHuman/MPFB CC0 source and CC0 release. In-place walk1.733s/30fps,1.7m/s equivalent according to primary page. Modern casual clothes make Sam unsuitable as period resident; use original authored walk as animation source.
- All53base joint names occur in Sam; extras lowerarm_prox_l,lowerarm_prox_r,held_accessory.154local transform fields differ (many tiny float differences, some meaningful), so retarget with rest-pose offsets; do not blindly paste absolute translation tracks.
- Backup `/tmp/art-human-selection/natural-male-innerscene.glb`: https://www.innerscene.com/tools/library/3d-parts/male-base-mesh-3d-person-rigged-a-pose-380e6d89 ; 4.3MB,109,064triangles,163joints,no clips,plain male unclothed CC0 MakeHuman adaptation. More joints to handle than53bone body.
- Source HTML snapshots `innerscene-53.html`, `innerscene-sam.html`, `innerscene-male.html` include explicit CC0 and provenance. Download links use respective `/api/library/<slug>/download` on www.innerscene.com.

Rejected char-kit: https://github.com/MMWilliams/char-kit . README explicitly says included motion is third-party and source licenses need checking. Upstream npcforge returns404. Do not publish its embedded animation. Source body is described as MakeHuman CC0 but apparel provenance is less explicit. No char-kit GLB downloaded.

## Earlier Quaternius candidate assessment

Verdict: useful licensed rigged assets obtained, but **do not approve the free male as the final Banished-like natural resident**. The suggested Regular Male is absent from the free Standard ZIP. Only the superhero male and female bodies are included; their exaggerated shoulders/muscles fail the requested natural style. The Regular models are in the paid Source edition ($19.99); no purchase/account was used.

Primary author sources:
- https://quaternius.com/packs/universalbasecharacters.html
- https://quaternius.itch.io/universal-base-characters
- https://quaternius.com/packs/universalanimationlibrary.html
- https://quaternius.itch.io/universal-animation-library
- https://creativecommons.org/publicdomain/zero/1.0/

The author pages and both downloaded internal license files say CC0 1.0, permitting modification and redistribution. Standard body license: `extracted/Universal Base Characters[Standard]/License_Standard.txt`. Animation license: `extracted/Universal Animation Library[Standard]/License.txt`.

## Downloaded files (all under /tmp/art-human-selection)

- `base-characters-standard.zip` — author's free 122MB archive.
- `animations-standard.zip` — author's free 15MB archive.
- `extracted/Universal Base Characters[Standard]/Base Characters/Godot - UE/Superhero_Male_FullBody.gltf` — skinned male body; matching .bin/textures alongside. Parsed actual file: 14,318 triangles; 3 meshes; one skin/65 joints; no animations. Not the Regular Male.
- `extracted/Universal Animation Library[Standard]/Unreal-Godot/UAL1_Standard.glb` — 7,618,436 bytes; one mannequin mesh, 13,744 triangles; one skin/65 joints; 43 animation clips. Includes Idle_Loop (2.5s/76 samples), Walk_Loop (1.333333s/41 samples), Walk_Formal_Loop (same duration). Each clip has 195 channels (translation/rotation/scale for 65 joints).
- `extracted/Universal Animation Library[Standard]/Unreal-Godot/UAL1_Standard_RM.glb` — corresponding root-motion variant. Prefer non-RM for game-controlled movement.
- `author-preview.jpg` — https://quaternius.com/assets/images/fullres/universalbasecharacters.jpg (inspected). The muscular center male is the free male; other proportions shown in the marketing sheet are not all free. Preview is documentation, not assumed covered by asset CC0.

## Integration notes

Character and animation GLB have identical 65 bone names but **different rest transforms** (185 translation/rotation/scale field differences measured). Do not blindly copy tracks and claim retargeting is validated. Need actual Babylon/Blender retarget validation. Animation GLB's own orange/purple mannequin is a technical test body, not a natural human resident.

Author glTF has two image URI issues: T_Hair_1_Normal_png.png and T_Eye_Normal_png.png do not appear alongside file; T_Hair_1_Normal.png and T_Eye_Normal.png do. Correct those references or embed corrected files during conversion. No repo edits performed.

Art adaptation still required: appropriate wool/linen skirt, bare upper body/period silhouette, historically suitable hairstyle/beard, neutral earth-colored texture. These are proposals, not completed work. Even with period clothes the free body remains distinctly superhero-stylized.

## Crowd LOD (implemented and visually verified)

`sumer-resident-lod.glb`:4,301triangles,299,496bytes,same53bones and Walk_Loop/Idle_Loop.200copies=860,200visible triangles before props. Directly built from original dense rest body using voxel-remesh(.017m),nearest-surface interpolated original bone weights and one reduction pass,plus lower-detail fitted scalp/beard/wrap. Fully clothed. Face/fingers intentionally simplified for distance. `prepare_lod.py` reproduces directly from original CC0 base/walk; `sumer-resident-lod.blend` is self-contained source; `lod-stats.json` and `roundtrip-lod-report.json` record numerical verification. Original hero GLB unchanged.

Both final GLBs were reimported through Blender and their complete animations checked for finite skinned coordinates and sane human-scale bounds; rendered exported walk/idle inspected. Use `preview-export-Walk_Loop.png`, `preview-export-Idle_Loop.png` for hero and `preview-export-lod-Walk_Loop.png`, `preview-export-lod-Idle_Loop.png` for crowd. There are no authoring widgets in either GLB. Blender creates its own hidden rig widget on import, which the verifier excludes explicitly.

## Final garment refinement (implemented)

`refine_wrap.py` cuts existing shoulder cloth against a diagonal plane (z=1.275+.60*x),covering one shoulder and leaving the other exposed. Existing skin weights and both animation clips remain intact.64short13mmfringe teeth added to each skirt hem with interpolated hem skin weights. Final triangle counts:hero22,125;crowd4,147. Final byte sizes:hero1,515,324;crowd296,240. Reproduce by running prepare_human.py,prepare_lod.py,then refine_wrap.py,then both verify_resident.py runs. `wrap-refinement-stats.json` supersedes earlier counts; original build stats describe pre-refinement asset.

## Final crowd draw-call optimization (implemented)

Current `sumer-resident-lod.glb` is318,140bytes,4,147triangles,ONE skinned mesh/primitive/material,53bones,Walk_Loop/Idle_Loop unchanged. Seven previous solid materials baked to FLOAT_COLOR corner attribute Color,exported as COLOR_0; single matte PBR material roughness.95. Rest meshes joined without applying skin modifier. `merge_crowd.py` builds `sumer-resident-lod-single.glb`/`.blend`; these verified outputs replaced the current LODfiles. Full animated roundtripbounds exactly match previousLOD and two rendered exportedclips inspected unchanged. `single-mesh-stats.json` records exact counts. Original7mesh files retained only as -multi backups. Hero unchanged. Rebuildpipeline:prepare_human.py → prepare_lod.py → refine_wrap.py → merge_crowd.py → verify candidate → copy-single candidate to finalLODnames. Re-running merge on already-joinedsource is safe.

## Final relaxed idle arms (implemented)

`relax_idle.py` updates only Idle_Loop on both saved rigs:upper arms11.8degrees from vertical,forearms downward with a small natural bend,wrists rotated so palms face thighs. Hands now hang near upper thighs rather than reaching forward. Skeleton proportions,geometry,materials and Walk_Loop unchanged; decoded exported Walk_Loop samples compare bit-for-bit identical(maxsampledifference0). `idle-arm-refinement.json` records elbow/wrist positions; `idle-hand-clearance.json` checks5,466hero+378LODhandvertices acrossframes0/45/90:no handvertices inside98%skirtellipticalenvelope(minnormalizedradius1.0596hero/1.1234LOD). Actualexportedidle/walkimagesrerendered and inspected; finalsourceGLB/.blendupdated. Reproduce this lastqualitypass after priorpipeline using relax_idle.py.
